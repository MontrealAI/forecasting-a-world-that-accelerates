Forecasting a World That Accelerates - preprint source v2.0.0

Compile main.tex with XeLaTeX and BibTeX. The complete protocol prompt is included in protocol/prompt.txt and embedded by Appendix A.
